-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2023 at 07:39 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bankon`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `firstName` varchar(10) NOT NULL,
  `lastName` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phoneNumber` int(14) NOT NULL,
  `dateOfOpening` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pin` varchar(5) NOT NULL,
  `accountNumber` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`firstName`, `lastName`, `address`, `phoneNumber`, `dateOfOpening`, `email`, `pin`, `accountNumber`) VALUES
('Tasin', 'Khan', 'Uttara, Dhaka, Dhaka, Bangladesh, 1230', 1631380297, '25/10/2023', 'tasin.khan@northsouth.edu', '12345', 12345678),
('Rafifa', 'Jahir', 'MirpurDhakaDhaka1235Bangladesh', 1752156873, '25/10/2023', 'rafifa@gmail.com', '54321', 16982455);

-- --------------------------------------------------------

--
-- Table structure for table `fraudalerts`
--

CREATE TABLE `fraudalerts` (
  `alert_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `from_account` varchar(255) DEFAULT NULL,
  `to_account` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fraudalerts`
--

INSERT INTO `fraudalerts` (`alert_id`, `date`, `time`, `amount`, `from_account`, `to_account`, `country`) VALUES
(1, '2023-10-26', '10:00:00', '1000.00', '1234567890', '9876543210', 'United States'),
(2, '2023-10-26', '11:00:00', '500.00', '0987654321', '1234567890', 'Canada'),
(3, '2023-10-26', '12:00:00', '250.00', '2345678901', '1098765432', 'Bangladesh'),
(4, '2023-10-26', '13:00:00', '100.00', '3456789012', '2109876543', 'Australia'),
(5, '2023-10-26', '14:00:00', '50.00', '4567890123', '3210987654', 'Germany');

-- --------------------------------------------------------

--
-- Table structure for table `loanapplications`
--

CREATE TABLE `loanapplications` (
  `ApplicationID` int(11) NOT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `LoanType` varchar(50) DEFAULT NULL,
  `LoanAmount` decimal(10,2) DEFAULT NULL,
  `EmploymentStatus` varchar(50) DEFAULT NULL,
  `AnnualIncome` decimal(10,2) DEFAULT NULL,
  `CreditScore` int(11) DEFAULT NULL,
  `ApplicationDate` date DEFAULT NULL,
  `Status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loanapplications`
--

INSERT INTO `loanapplications` (`ApplicationID`, `CustomerID`, `LoanType`, `LoanAmount`, `EmploymentStatus`, `AnnualIncome`, `CreditScore`, `ApplicationDate`, `Status`) VALUES
(0, 12345, 'Personal', '10000.00', 'Employed', '50000.00', 750, '2023-10-27', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `LoanID` int(11) NOT NULL,
  `LoanType` varchar(50) DEFAULT NULL,
  `InterestRate` decimal(5,2) DEFAULT NULL,
  `MaxLoanAmount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Name` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phoneNumber` int(14) DEFAULT NULL,
  `accountNumber` int(8) NOT NULL,
  `Quantity` varchar(10) DEFAULT NULL,
  `Type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Name`, `Email`, `address`, `phoneNumber`, `accountNumber`, `Quantity`, `Type`) VALUES
('Rifah_Anjum', 'rifah.anjum@example.com', '27-Paltan', 277677, 12345678, '1', 'Personal');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `Name` varchar(50) NOT NULL,
  `accountNumber` int(8) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` date NOT NULL,
  `paymentStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`Name`, `accountNumber`, `amount`, `date`, `paymentStatus`) VALUES
('Ali Traders', 783908, 32000, '2023-10-20', 'paid'),
('Johnson Smith', 998342, 25000, '2023-10-23', 'Pending'),
('Easy Dhaka', 4536489, 40000, '2023-09-08', 'Paid'),
('Dali Enterprise', 6489463, 60000, '2023-08-28', 'Paid');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`accountNumber`);

--
-- Indexes for table `fraudalerts`
--
ALTER TABLE `fraudalerts`
  ADD PRIMARY KEY (`alert_id`);

--
-- Indexes for table `loanapplications`
--
ALTER TABLE `loanapplications`
  ADD PRIMARY KEY (`ApplicationID`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`LoanID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`accountNumber`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`accountNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fraudalerts`
--
ALTER TABLE `fraudalerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
